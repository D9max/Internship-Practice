import java.util.Scanner;

public class Usecase3 {
  public static void main(String[] args) {
    Double sub1, sub2, sub3, totalmarks;
    double avg;

    Scanner scan = new Scanner(System.in);
    System.out.println("Enter grade of three subjects: ");
    System.out.println("enter sub1 marks");
    sub1 = scan.nextDouble();
    System.out.println("enter sub2 marks");
    sub2 = scan.nextDouble();
    System.out.println("enter sub3 marks");
    sub3 = scan.nextDouble();

    totalmarks = sub1 + sub2 + sub3;

    avg = (double) totalmarks / 3;

    System.out.println("Average of Marks : " + Math.round(avg));

    scan.close();
  }
}
