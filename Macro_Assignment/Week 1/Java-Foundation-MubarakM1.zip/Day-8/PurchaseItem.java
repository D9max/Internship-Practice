import java.util.Scanner;

public class PurchaseItem {
    public static void main(String[] args) {
      int stock_items;
      int item;
      Double price,money;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the item you want to purchase");
        item = sc.nextInt();
        System.out.println("Enter the price of the item");
         price = sc.nextDouble();
        System.out.println("Enter the amount of money you have in your account");
         money = sc.nextDouble();
        System.out.println("Enter the amount of item in stock");
         stock_items = sc.nextInt();
        if (stock_items > 0 && money >= price) {
            System.out.println("Your transaction is processed");
        } else if (stock_items == 0) {
            System.out.println("Sorry, the item is out of stock");
        } else if (money < price) {
            System.out.println("Sorry, you do not have enough money");
        }
    }
}