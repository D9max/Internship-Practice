import java.util.*;

class Employee {
  public static void main(String args[]) {
    int salary, HRA, DA;
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter the basic salary of an employee");
    salary = sc.nextInt();

    if (salary <= 1000) {
      HRA = (20 / 100) * salary;
      DA = (80 / 100) * salary;
      GS = salary + DA + HRA;

    } else if (salary <= 2000) {
      HRA = (25 / 100) * salary;
      DA = (90 / 100) * salary;
      GS = salary + DA + HRA;

    } else if (salary > 2000) {
      HRA = (30 / 100) * salary;
      DA = (95 / 100) * salary;
      GS = salary + DA + HRA;

    }
    System.out.println("gross salary :" + GS);
  }

}
