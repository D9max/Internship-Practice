import java.util.*;

public class UpperLowerCase {
  public static void main(String args[]) {
    char ch;
    Scanner sc = new Scanner(System.in);
    System.out.println("enter a character");
    ch = sc.next().charAt(0);
    if (ch >= 'A' && ch <= 'Z') {
      System.out.println("character enterd in upper case");
    } else if (ch >= 'a' && ch <= 'z') {
      System.out.println(" is a lower case letter ");

    }
  }
}
