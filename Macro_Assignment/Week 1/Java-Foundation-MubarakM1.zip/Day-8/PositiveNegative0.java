import java.util.*;

public class PositiveNegative0 {
  public static void main(String[] args) {
    int num;
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter the number ");
    num= sc.nextInt();
    if(num>0){
      System.out.println("number is positive ");
    }
      else if(num<0){
        System.out.println("number is negetive");
      }
    else{
      System.out.println("the given number is zero");
  }
}
}
