import java.util.Scanner;

public class Logging {
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    System.out.println("enter your email address or username");
    String email = sc.nextLine();
    if (email.contains("@")) {
      System.out.println("Your email address is valid");
    } else {
      System.out.println("Your username is valid");
    }
  }
}