import java.util.*;

public class EmployeeBonus {
  public static void main(String[] args) {
    double salary, bonus;
    String perf;
    Scanner sc = new Scanner(System.in);
    System.out.println("enter your salary: ");
    salary = sc.nextDouble();
    System.out.println("your performance: ");
    perf = sc.next();
    bonus = 0;
    if (perf.equals("Excellent")) {
      bonus = salary * 0.1;
    } else if (perf.equals("Good")) {
      bonus = salary * 0.05;
    } else if (perf.equals("Average")) {
      bonus = salary * 0.02;
    } else if (perf.equals("Poor")) {
    }
    System.out.println("Your bonus is: " + bonus);
  }
}