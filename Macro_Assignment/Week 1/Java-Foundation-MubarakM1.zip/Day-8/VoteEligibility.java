import java.util.*;
public class VoteEligibility {
 public static void main(String[] args) 
 {
    int age;
    Scanner sc = new Scanner(System.in);
    System.out.println("enter your age: ");
    age = sc.nextInt();

    if(age>=18) 
    {
        System.out.println("You are eligible for voting.");
    }
    else
    System.out.println("Sorry You can vote after: "+18+" years");
    }
 }
//32 character

