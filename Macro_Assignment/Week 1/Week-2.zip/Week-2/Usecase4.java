import java.util.Scanner;

public class Usecase4 {
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    System.out.println("Details About Book :\n");
    System.out.println("enter Book name");
    String num1 = sc.next();

    System.out.println("enter Book Author name");
    String num2 = sc.next();

    System.out.println("enter Book Title");
    String num3 = sc.next();

    System.out.println("enter Book Language");
    String num4 = sc.next();
    System.out.println("\n");

    System.out.println("Details About Member :\n");

    System.out.println("enter Member_id");
    String num5 = sc.next();

    System.out.println("enter member name ");
    String num6 = sc.next();

    System.out.println("Book name :" + num1);
    System.out.println("Book Author :" + num2);
    System.out.println("book Title :" + num3);
    System.out.println("Language :" + num4);
    System.out.println("Member_id :" + num5);
    System.out.println("Member name :" + num6);
  }
}

