
public class Usecase1
{
    public static void main(String[] args)
    {
     int num1= 230;   
      System.out.println("CoffeeBeans ="+num1);
    }
}
