import java.util.Scanner;

public class Usecase5 {
    public static void main(String[] args) {
        int Totaltax,Totalcoast; 
        
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter cost of food ");
        int food = sc.nextInt();
    
      System.out.println("Enter How much tax will be added ");
        int tax = sc.nextInt();
      
        Totaltax = (food*tax)/100;

       System.out.println("Enter tip as much as you want");
        int tip = sc.nextInt();
      
      Totalcoast = food+tax+tip;
      
      System.out.println("Total coast of food is :"+Totalcoast);
    }
}