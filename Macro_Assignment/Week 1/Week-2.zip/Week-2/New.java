import java.util.Scanner;

public class New {
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);

    System.out.println("enter integer number");
    int num1 = sc.nextInt();

    System.out.println("enter Double number ");
    Double num2 = sc.nextDouble();

    System.out.println("enter boolean value");
    Boolean num3 = sc.nextBoolean();

    System.out.println("enter character");
    char num4 = sc.next().charAt(0);

    System.out.println("Integer is:" + num1);
    System.out.println("Double Value is:" + num2);
    System.out.println("Boolean Value is:" + num3);
    System.out.println("Character is:" + num4);

  }
}