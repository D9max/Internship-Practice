import java.util.Scanner;
public class Usecase2
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);

 	 System.out.println("enter room rate");
        int num1=sc.nextInt();
   System.out.println("enter no.of.nights");
        int num2=sc.nextInt();
       double result = num1*num2;
   System.out.println(num1 + "*" + num2 + " = " + result);
    
    }
}