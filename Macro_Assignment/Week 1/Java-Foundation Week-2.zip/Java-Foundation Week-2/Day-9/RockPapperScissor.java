import java.util.Scanner;

public class RockPapperScissor {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter your choice: ");
        System.out.println("1. Rock");
        System.out.println("2. Paper");
        System.out.println("3. Scissors");
        int userChoice = sc.nextInt();
        int computerChoice = (int) (Math.random() * 3) + 1;
        if (userChoice == 1 && computerChoice == 1) {
            System.out.println("It's a tie!");
        } else if (userChoice == 1 && computerChoice == 2) {
            System.out.println("You lose!");
        } else if (userChoice == 1 && computerChoice == 3) {
            System.out.println("You win!");
        } else if (userChoice == 2 && computerChoice == 1) {
            System.out.println("You win!");
        } else if (userChoice == 2 && computerChoice == 2) {
            System.out.println("It's a tie!");
        } else if (userChoice == 2 && computerChoice == 3) {
            System.out.println("You lose!");
        } else if (userChoice == 3 && computerChoice == 1) {
            System.out.println("You lose!");
        } else if (userChoice == 3 && computerChoice == 2) {
            System.out.println("You win!");
        } else if (userChoice == 3 && computerChoice == 3) {
            System.out.println("It's a tie!");
        }
    }
}