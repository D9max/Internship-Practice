import java.util.*;
public class CalculatorOperator{
	public static void main(String[] args) {
    int num1,num2;
    char a;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the first number");
		num1 = sc.nextInt();
		System.out.println("Enter the second number");
		num2 = sc.nextInt();
		System.out.println("Enter the operator what you want to perform ");
	  a = sc.next().charAt(0);
    if(a=='+'){
      System.out.println("Addition of two numbers is "+(num1+num2));
    }
    else if(a=='-'){
      System.out.println("Addition of two numbers is "+(num1-num2));
    }
    if(a=='*'){
      System.out.println("Addition of two numbers is "+(num1*num2));
    }
    if(a=='/'){
      System.out.println("Addition of two numbers is "+(num1/num2));
    }
    else
		// switch(a) {
		// case '+':
		// 	System.out.println("Addition of two numbers is "+(num1+num2));
		// 	break;
		// case '-':
		// 	System.out.println("Subtraction of two numbers is "+(num1-num2));
		// 	break;
		// case '*':
		// 	System.out.println("Multiplication of two numbers is "+(num1*num2));
		// 	break;
		// case '/':
		// 	System.out.println("Division of two numbers is "+(num1/num2));
		// 	break;
		// default:
			System.out.println("Invalid operator");
		}
	}