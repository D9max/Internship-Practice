import java.util.*;

public class Password {
  public static void main(String[] args) {
    String password, userPassword;
    Scanner sc = new Scanner(System.in);
    password = "abc123";
    System.out.println("Enter the password: ");
    userPassword = sc.nextLine();
    if (userPassword.equals(password)) {
      System.out.println("Welcome");
    } else {
      System.out.println("you enterd Wrong password");
    }
  }
}
