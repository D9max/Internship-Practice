// import java.util.*;

// public class TrafficLightSimulator {
//   public static void main(String[] args) {
//     int time, traffic;
//     Scanner sc = new Scanner(System.in);
//     System.out.println("Enter the time of day in 24 hour format");
//     time = sc.nextInt();
//     System.out.println("Enter the traffic flow");
//     traffic = sc.nextInt();
//     if (time >= 0 && time <= 23) {
//       if (time >= 0 && time <= 6) {
//         System.out.println("The traffic light is green");
//       } else if (time >= 7 && time <= 9) {
//         if (traffic >= 0 && traffic <= 10) {
//           System.out.println("The traffic light is green");
//         } else if (traffic >= 11 && traffic <= 20) {
//           System.out.println("The traffic light is yellow");
//         } else if (traffic >= 21 && traffic <= 30) {
//           System.out.println("The traffic light is red");
//         }
//       } else if (time >= 10 && time <= 15) {
//         if (traffic >= 0 && traffic <= 10) {
//           System.out.println("The traffic light is green");
//         } else if (traffic >= 11 && traffic <= 20) {
//           System.out.println("The traffic light is yellow");
//         } else if (traffic >= 21 && traffic <= 30) {
//           System.out.println("The traffic light is red");
//         }
//       } else if (time >= 16 && time <= 18) {
//         if (traffic >= 0 && traffic <= 10) {
//           System.out.println("The traffic light is green");
//         } else if (traffic >= 11 && traffic <= 20) {
//           System.out.println("The traffic light is yellow");
//         } else if (traffic >= 21 && traffic <= 30) {
//           System.out.println("The traffic light is red");
//         }
//       } else if (time >= 19 && time <= 23) {
//         System.out.println("The traffic light is green");
//       }
//     } else {
//       System.out.println("Invalid time");
//     }
//   }
// }

import java.util.*;

class TrafficLightSimulator {
  public static void main(String args[]) {
    Scanner sc = new Scanner(System.in);
    System.out.println("enter the traffic flow : ");
    String trafficflow = sc.next();
    System.out.println("enter the time : ");
    int time = sc.nextInt();
    if ((time >= 8 && time < 10) && (trafficflow.equals("heavy"))) {
      System.out.println("red light for east-west and green for north-south");
    } else if ((time >= 10 && time < 12) && (trafficflow.equals("heavy"))) {
      System.out.println("green light for east-west and red for north-south");
    } else if ((time >= 12 && time < 14) && (trafficflow.equals("heavy"))) {
      System.out.println("red light for east-west and green for north-south");
    } else if ((time >= 14 && time < 16) && (trafficflow.equals("heavy"))) {
      System.out.println("red light for east-west and green for north-south");
    } else
      System.out.println("yellow for all directions");

  }
}