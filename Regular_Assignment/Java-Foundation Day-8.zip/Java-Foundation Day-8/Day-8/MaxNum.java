import java.util.*;

public class Main {
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter the firstnumber: ");
    int firstnumber = sc.nextInt();
    System.out.println("Enter the secondnumber: ");
    int secondnumber = sc.nextInt();
    if (firstnumber > secondnumber)
      System.out.println("first number is max ");
    else
      System.out.println("second number is max");
  }
}

if (firstnumber > secondnumber)&&(firstnumber > thirdnumber)
  {
   System.out.println("max first ");
  }
else if (secondnumber>firstnumber)&&(second>third)
  second number max
  else
  third number

  //