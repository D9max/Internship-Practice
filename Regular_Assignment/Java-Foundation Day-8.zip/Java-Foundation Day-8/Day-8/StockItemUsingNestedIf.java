import java.util.Scanner;

public class StockItemUsingNestedIf {
  public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
    System.out.println("Enter purchase item");
    String item = input.nextLine();
    System.out.println("Enter the price of the item");
    double price = input.nextDouble();
    System.out.println("Enter the amount of money you have in your account");
    double money = input.nextDouble();
    if (stock > 0) {
      if (money >= price) {
        System.out.println("Transaction is processed");
      } else {
        System.out.println("Please add more money to your account");
      }
    } else {
      System.out.println("out of stack Please try again later");
    }
  }
}