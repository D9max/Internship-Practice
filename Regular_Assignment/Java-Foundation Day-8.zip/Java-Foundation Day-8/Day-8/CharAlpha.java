import java.util.Scanner;

public class CharAlpha {

  public static void main(String[] args) {
    char ch;
    Scanner sc = new Scanner(System.in);

    System.out.println("Enter any caracter : ");
    ch = sc.next().charAt(0);

    if ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z')) {

      System.out.println("is a alphabet");

    } else {

      System.out.println("is not a alphabet");

    }
  }
}
