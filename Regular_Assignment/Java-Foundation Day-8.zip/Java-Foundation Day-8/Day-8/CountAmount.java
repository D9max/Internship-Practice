// import java.util.Scanner;

// public class CountAmount {
//   public static void main(String[] args) {
//     int hundred, Twohundred, fivehundred;
//     Scanner sc = new Scanner(System.in);
//     System.out.print("Enter number of 100 rupees notes: ");
//     hundred = sc.nextInt();
//     System.out.print("Enter number of 200 rupees notes: ");
//     Twohundred = sc.nextInt();
//     System.out.print("Enter number of 500 rupees notes: ");
//     fivehundred = sc.nextInt();

//     int totalAmount = hundred + Twohundred + fivehundred;

//     System.out.println("Total amount is " + totalAmount);
//   }
// }

import java.util.Scanner;

public class CountAmount {
  public static void main(String[] args) {
    int amount;
    int nof2000notes, nof500notes, nof200notes, nof100notes, nof50notes, nof20notes, nof10notes, nof5notes;
    Scanner sc = new Scanner(System.in);
    System.out.print("Enter the numbert of notes ");
    amount = sc.nextInt();
    if (amount >= 2000) {
      nof2000notes = amount / 2000;
      amount = amount - nof2000notes * 2000;
      System.out.println("2000 notes are:" + nof2000notes);
    }
    if (amount >= 500) {
      nof500notes = amount / 500;
      amount = amount - nof500notes * 500;
      System.out.println("500 notes are :" + nof500notes);
    }
    if (amount >= 100) {
      nof100notes = amount / 100;
      amount = amount - nof100notes * 100;
      System.out.println("100 notes are:" + nof100notes);
    }
    if (amount >= 50) {
      nof50notes = amount / 50;
      amount = amount - nof50notes * 50;
      System.out.println("50 notes are:" + nof50notes);
    }
    if (amount >= 10) {
      nof10notes = amount / 10;
      amount = amount - nof10notes * 10;
      System.out.println("10 notes are:" + nof10notes);
    }
    if (amt >= 5) {
      nof5notes = amount / 5;
      amount = amount - nof5notes * 5;
      System.out.println("number of 5 notes=" + nof5notes);
    }
    System.out.println("total amount=" + (nof2000notes + nof100notes + nof50notes + nof50notes + nof10notes));
  }
}
