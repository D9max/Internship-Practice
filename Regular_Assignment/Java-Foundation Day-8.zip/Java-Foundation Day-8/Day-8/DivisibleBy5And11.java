import java.util.*;

class DivisibleBy5And11 {
  public static void main(String args[]) {
    int num;
    Scanner sc = new Scanner(System.in);
    System.out.print("Enter a number: ");
    num = sc.nextInt();

    if ((num % 5 == 0) && (num % 11 == 0)) {
      System.out.println("Number is divisible");
    } else {
      System.out.println("Number is not Divisible");
    }
  }
}