import java.util.Scanner;

public class CalculateYearMonthDays {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter your birth date: ");
        int birthDate = scanner.nextInt();
        System.out.println("Enter your birth month: ");
        int birthMonth = scanner.nextInt();
        System.out.println("Enter your birth year: ");
        int birthYear = scanner.nextInt();
        System.out.println("Enter current date: ");
        int currentDate = scanner.nextInt();
        System.out.println("Enter current month: ");
        int currentMonth = scanner.nextInt();
        System.out.println("Enter current year: ");
        int currentYear = scanner.nextInt();
        int age = currentYear - birthYear;
        if (birthMonth > currentMonth) {
            age--;
        } else if (birthMonth == currentMonth) {
            if (birthDate > currentDate) {
                age--;
            }
        }
        System.out.println("Your age is: " + age);
    }
}