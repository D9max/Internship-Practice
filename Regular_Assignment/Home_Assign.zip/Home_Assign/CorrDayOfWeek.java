import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;

public class DiffBeTwoDays {
  public static void main(String[] args) {
    String D1, D2;
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter first date in format yyyy-mm-dd");
    D1 = sc.next();
    System.out.println("Enter second date in format yyyy-mm-dd");
    D2 = sc.next();
    LocalDate date1 = LocalDate.parse(D1);
    LocalDate date2 = LocalDate.parse(D2);
    Period period = Period.between(date1, date2);
    System.out.println("Difference between two dates is " + period.getDays() + "weeks.");
  }
}