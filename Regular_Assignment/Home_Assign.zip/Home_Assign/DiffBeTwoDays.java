// import java.util.Scanner;
// import java.time.LocalDate;
// import java.time.Period;

// public class DiffBeTwoDays {
// 	public static void main(String[] args) {
//     String date1,date2;
// 		Scanner input = new Scanner(System.in);
// 		System.out.println("Enter the first date in the format yyyy-mm-dd: ");
// 		date1 = input.nextLine();
// 		System.out.println("Enter the second date in the format yyyy-mm-dd: ");
// 	  date2 = input.nextLine();
// 		LocalDate d1 = LocalDate.parse(date1);
// 		LocalDate d2 = LocalDate.parse(date2);
// 		Period p = Period.between(d1, d2);
// 		System.out.println("The difference between the two dates is " + p.getYears() + " years, " + p.getMonths() + " months, and " + p.getDays() + " days.");
// 	}
// }

import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;

public class DiffBeTwoDays {
  public static void main(String[] args) {
    String D1, D2;
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter first date in format yyyy-mm-dd");
    D1 = sc.next();
    System.out.println("Enter second date in format yyyy-mm-dd");
    D2 = sc.next();
    LocalDate date1 = LocalDate.parse(D1);
    LocalDate date2 = LocalDate.parse(D2);
    Period period = Period.between(date1, date2);
    System.out.println("Difference between two dates is " + period.getDays() + " days,");
  }
}