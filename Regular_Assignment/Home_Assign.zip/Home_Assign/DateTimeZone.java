
//  Europe/London
// Asia/Tokyo
//America/New_York
// Australia/Sydney

import java.util.Scanner;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

public class Main {
  public static void main(String[] args) {
    String dateString, zoneString;
    Scanner input = new Scanner(System.in);
    System.out.print("Enter a date yyyy-MM-dd");
    dateString = input.nextLine();
    System.out.print("Enter a time zone ");
    zoneString = input.nextLine();
    LocalDate date = LocalDate.parse(dateString);
    LocalTime time = LocalTime.now();
    ZoneId zone = ZoneId.of(zoneString);
    ZonedDateTime zonedDateTime = ZonedDateTime.of(date, time, zone);
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss z");

    System.out.println("Date and Time: " + formatter.format(zonedDateTime));

  }

}