import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Welcome to the Java application!");
        System.out.println("Please select an option:");
        System.out.println("1. Calculator");
        System.out.println("2. Converter");
        System.out.println("3. Random number generator");
        System.out.println("4. Quit");
        int option = input.nextInt();
        if (option == 1) {
            System.out.println("Please select an option:");
            System.out.println("a. Addition");
            System.out.println("b. Subtraction");
            System.out.println("c. Multiplication");
            System.out.println("d. Division");
            String option2 = input.next();
            if (option2.equals("a")) {
                System.out.println("Please enter the first number:");
                int num1 = input.nextInt();
                System.out.println("Please enter the second number:");
                int num2 = input.nextInt();
                System.out.println("The result is: " + (num1 + num2));
            } else if (option2.equals("b")) {
                System.out.println("Please enter the first number:");
                int num1 = input.nextInt();
                System.out.println("Please enter the second number:");
                int num2 = input.nextInt();
                System.out.println("The result is: " + (num1 - num2));
            } else if (option2.equals("c")) {
                System.out.println("Please enter the first number:");
                int num1 = input.nextInt();
                System.out.println("Please enter the second number:");
                int num2 = input.nextInt();
                System.out.println("The result is: " + (num1 * num2));
            } else if (option2.equals("d")) {
                System.out.println("Please enter the first number:");
                int num1 = input.nextInt();
                System.out.println("Please enter the second number:");
                int num2 = input.nextInt();
                if (num2 == 0) {
                    System.out.println("Division by zero is not allowed!");
                } else {
                    System.out.println("The result is: " + (num1 / num2));
                }
            }
        } else if (option == 2) {
            System.out.println("Please select an option:");
            System.out.println("a. Celsius to Fahrenheit");
            System.out.println("b. Fahrenheit to Celsius");
            System.out.println("c. Kilometers to Miles");
            System.out.println("d. Miles to Kilometers");
            String option2 = input.next();
            if (option2.equals("a")) {
                System.out.println("Please enter the temperature in Celsius:");
                double temp = input.nextDouble();
                System.out.println("The temperature in Fahrenheit is: " + (temp * 1.8 + 32));
            } else if (option2.equals("b")) {
                System.out.println("Please enter the temperature in Fahrenheit:");
                double temp = input.nextDouble();
                System.out.println("The temperature in Celsius is: " + ((temp - 32) / 1.8));
            } else if (option2.equals("c")) {
                System.out.println("Please enter the distance in kilometers:");
                double dist = input.nextDouble();
                System.out.println("The distance in miles is: " + (dist / 1.609));
            } else if (option2.equals("d")) {
                System.out.println("Please enter the distance in miles:");
                double dist = input.nextDouble();
                System.out.println("The distance in kilometers is: " + (dist * 1.609));
            }
        } else if (option == 3) {
            System.out.println("The random number is: " + (int) (Math.random() * 100 + 1));
        } else if (option == 4) {
            System.out.println("Goodbye...!");
        }
    }
}