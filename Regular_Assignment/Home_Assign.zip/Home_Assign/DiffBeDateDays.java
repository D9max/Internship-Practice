import java.util.Scanner;

public class DiffBeDateDays {
  public static void main(String[] args) {
    int days, day, month, year, newDay, newMonth, newYear;
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter a date in the format dd/mm/yyyy");
    String date = sc.nextLine();
    System.out.println("Enter the number of days to add");
    days = sc.nextInt();
    String[] dateArray = date.split("/");
    day = Integer.parseInt(dateArray[0]);
    month = Integer.parseInt(dateArray[1]);
    year = Integer.parseInt(dateArray[2]);
    newDay = day + days;
    newMonth = month;
    newYear = year;
    if (newDay > 30) {
      newDay = newDay - 30;
      newMonth = month + 1;
      if (newMonth > 12) {
        newMonth = newMonth - 12;
        newYear = year + 1;
      }
    }
    System.out.println("The new date is " + newDay + "/" + newMonth + "/" + newYear);
  }
}