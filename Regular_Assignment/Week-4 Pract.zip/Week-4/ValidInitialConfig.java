
import java.util.Scanner;

class ValidInitialConfig {
  public static void main(String[] args) {
    int n;
    int a[][] = new int[50][50];
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter no of rows");
    n = sc.nextInt();
    System.out.println("Enter elements here:");
    for (int i = 0; i < n; i++) {
      for (int j = 0; j < n; j++) {
        a[i][j] = sc.nextInt();
      }
      System.out.println();
    }
    for (int i = 0; i < n; i++) {
      for (int j = 0; j < n; j++) {
        if (a[i][j] > 10 && a[i][j] != 20) {
          System.out.println("No");
          return;
        }
      }
    }
    System.out.println("Yes");
  }
}
