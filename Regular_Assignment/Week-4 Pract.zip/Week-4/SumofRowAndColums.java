import java.util.Scanner;

public class SumofRowAndColums {

  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter the number of rows and columns of matrix");
    int row = sc.nextInt();
    int column = sc.nextInt();
    int[][] matrix = new int[row][column];
    System.out.println("Enter the elements of matrix");
    for (int i = 0; i < row; i++) {
      for (int j = 0; j < column; j++) {
        matrix[i][j] = sc.nextInt();
      }
    }
    System.out.println("The matrix is");
    for (int i = 0; i < row; i++) {
      for (int j = 0; j < column; j++) {
        System.out.print(matrix[i][j] + " ");
      }
      System.out.println();
    }
    int sum = 0;
    for (int i = 0; i < row; i++) {
      for (int j = 0; j < column; j++) {
        sum = sum + matrix[i][j];
      }
      System.out.println("Sum of " + (i + 1) + " row is " + sum);
      sum = 0;
    }
    for (int i = 0; i < column; i++) {
      for (int j = 0; j < row; j++) {
        sum = sum + matrix[j][i];
      }
      System.out.println("Sum of " + (i + 1) + " column is " + sum);
      sum = 0;
    }
  }
}