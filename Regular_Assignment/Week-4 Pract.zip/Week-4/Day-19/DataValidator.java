import java.util.Scanner;

public class DataValidator {
  public static boolean emailVerifier(String email) {
    String regex = "^[a-zA-Z0-9_+&*-]+(?:\\." + "[a-zA-Z0-9_+&*-]+)*@" + "(?:[a-zA-Z0-9-]+\\.)+[a-z" + "A-Z]{2,7}$";
    if (email.matches(regex)) {
      return true;
    } else {
      return false;
    }
  }

  public static boolean usernamePasswordVerifier(String username, String password) {
    String regex = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}$";
    if (username.matches(regex) && password.matches(regex)) {
      return true;
    } else {
      return false;
    }
  }

  public static boolean mobileNumberVerifier(String mobile) {
    String regex = "^[6-9]{1}[0-9]{9}$";
    if (mobile.matches(regex)) {
      return true;
    } else {
      return false;
    }
  }

  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter your choice: ");
    System.out.println("1. Email Verifier");
    System.out.println("2. Username and password Verifier");
    System.out.println("3. Mobile number Verifier");
    int choice = sc.nextInt();
    switch (choice) {
      case 1:
        System.out.println("Enter your email address: ");
        String email = sc.next();
        if (emailVerifier(email)) {
          System.out.println("Email is valid");
        } else {
          System.out.println("Email is invalid");
        }
        break;
      case 2:
        System.out.println("Enter your username: ");
        String username = sc.next();
        System.out.println("Enter your password: ");
        String password = sc.next();
        if (usernamePasswordVerifier(username, password)) {
          System.out.println("Username and password are valid");
        } else {
          System.out.println("Username and password are invalid");
        }
        break;
      case 3:
        System.out.println("Enter your mobile number: ");
        String mobile = sc.next();
        if (mobileNumberVerifier(mobile)) {
          System.out.println("Mobile number is valid");
        } else {
          System.out.println("Mobile number is invalid");
        }
        break;
      default:
        System.out.println("Invalid choice");
        break;
    }
  }
}