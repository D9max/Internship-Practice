import java.util.*;
public class ReplaceMethod{
  public static void replaceChar(String str1,String str2){
    System.out.println(str1.replace("i", "@"));
  }
  public static void main(String args[]){
  replaceChar("Bitlabs","@");
}
}