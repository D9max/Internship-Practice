class ToSubStringMethod {
  static void sub(String s) {
    System.out.println(s.substring(7));
  }

  public static void main(String args[]){
    sub("lional messi");
  }
}