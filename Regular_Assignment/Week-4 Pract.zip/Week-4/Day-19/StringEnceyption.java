import java.util.Scanner;

public class StringEnceyption {
  public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
    System.out.println("Enter a string to encrypt: ");
    String str = input.nextLine();
    System.out.println("Enter a key: ");
    int key = input.nextInt();
    String encrypted = "";
    for (int i = 0; i < str.length(); i++) {
      char ch = str.charAt(i);
      if (Character.isLetter(ch)) {
        if (Character.isLowerCase(ch)) {
          char c = (char) (ch + key);
          if (c > 'z') {
            encrypted += (char) (ch - (26 - key));
          } else {
            encrypted += c;
          }
        } else if (Character.isUpperCase(ch)) {
          char c = (char) (ch + key);
          if (c > 'Z') {
            encrypted += (char) (ch - (26 - key));
          } else {
            encrypted += c;
          }
        }
      } else {
        encrypted += ch;
      }
    }
    System.out.println("Encrypted string: " + encrypted);
  }
}