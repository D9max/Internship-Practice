import java.util.*;

class StringContainSpecialChar {
  static void validString(String s1) {
    if (s1.contains("@")) {
      System.out.println("valid - " + s1.indexOf("@"));
    } else
      System.out.println("invalid");
  }

  public static void main(String args[]){
    Scanner sc=new Scanner(System.in);
    System.out.println("enter string");
    
    validString(s1);
    String s1=sc.nextLine();
  }  
}}