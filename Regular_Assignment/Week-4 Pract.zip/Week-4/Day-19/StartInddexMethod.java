class StartInddexMethod {
  static void starts(String s) {
    boolean b = s.startsWith("m");
    System.out.println(b);
  }

  public static void main(String args[]){
    starts("lional messi");
  }
}