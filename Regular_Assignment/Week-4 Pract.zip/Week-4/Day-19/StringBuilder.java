import java.util.Scanner;
class StringBuilder{
  public static void main(String args[]){
    Scanner sc=new Scanner(System.in);
    StringBuilder sb=new StringBuilder("Hi Hello");
    sb.append(" Kundapura ");
    System.out.println(sb);
  }
}