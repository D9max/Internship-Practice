// import java.util.*;

// public class ArrayDemo {
//   public static void main(String args[]) {
//     int arr[] = { 12, 34, 56, 67, 89, 90 };
//     int index = 3;
//     int arr1[] = new int[arr.length];
//     for (int i = 0; i < arr.length; i++) {
//       if (i < index) {
//         arr1[i] = arr[i];
//       } else {
//         arr1[i] = arr[i + index];
//       }
//     }
//     for (int i = 0; i < arr.length; i++) {
//       System.out.println(arr1[i] + " ");
//     }
//   }
// }
import java.util.Scanner;

class ArrayDemo {
  public static void main(String args[]) {
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter the size of array");
    int n = sc.nextInt();
    int arr[] = new int[n];
    System.out.println("Enter the elements of array");
    for (int i = 0; i < n; i++) {
      arr[i] = sc.nextInt();
    }
    System.out.println("Enter the index to rotate");
    int index = sc.nextInt();
    int temp = arr[index];
    for (int i = index; i < n - 1; i++) {
      arr[i] = arr[i + 1];
    }
    arr[n - 1] = temp;
    System.out.println("After rotating the array is");
    for (int i = 0; i < n; i++) {
      System.out.print(arr[i] + " ");
    }
  }
}