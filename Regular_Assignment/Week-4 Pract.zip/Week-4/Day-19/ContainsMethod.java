import java.util.*;
public class ContainsMethod {
    public static boolean containsSequence(String inputString, String sequence) {
        return inputString.contains(sequence);
    }

    public static void main(String[] args) {
        String inputString = "The quick brown fox jumps over the lazy dog";
        String sequence = "brown";
        if (StringChecker.containsSequence(inputString, sequence)) {
            System.out.println("The input string contains the sequence: " + sequence);
        } else {
            System.out.println("The input string does not contain the sequence: " + sequence);
        }
    }
}
