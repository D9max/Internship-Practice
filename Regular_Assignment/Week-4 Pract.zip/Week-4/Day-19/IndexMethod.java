public class IndexMethod {
  public static void main(String args[]) {
    String mystr = "Welcome to Bitlabs";
    System.out.println(mystr.indexOf("Bitlabs"));
  }
}
