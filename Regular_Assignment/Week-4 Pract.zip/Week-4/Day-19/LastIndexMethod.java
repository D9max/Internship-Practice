class LastIndexMethod {
  static void lastIndex(String s) {
    int lastindex = s.lastIndexOf('m');
    System.out.println(lastindex);
  }

  public static void main(String args[]){
    lastIndex("lional messi");
  }
}