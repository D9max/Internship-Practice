import java.util.*;
class StringLastIndex{
public static void main(String args[]){
  StringBuffer str=new StringBuffer();
  Scanner sc=new Scanner(System.in);
  System.out.println("enter String");
  str.append("StringBuffer is a mutable string and we can modify");
  //String str1=str.toString();
System.out.println(str.("m"));
}
}
  
