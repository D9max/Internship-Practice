import java.util.Scanner;

public class StringReplace {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a string: ");
		String str = sc.nextLine();
		System.out.println("Enter a sentence: ");
		String word = sc.nextLine();
		System.out.println("Enter sentence replace with: ");
		String replace = sc.nextLine();
		String newStr = str.replaceAll(word, replace);
		System.out.println("New string: " + newStr);
	}
}