import java.util.Scanner;

public class MaxArray {
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter a string:");
    String s = sc.nextLine();

    char maxChar = ' ';
    int maxCount = 0;
    for (int i = 0; i < s.length(); i++) {
      char c = s.charAt(i);
      int count = 1;
      for (int j = i + 1; j < s.length(); j++) {
        if (c == s.charAt(j)) {
          count++;
        }
      }
      if (count > maxCount) {
        maxCount = count;
        maxChar = c;
      }
    }
    System.out.println(maxChar);
  }
}
