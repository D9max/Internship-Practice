import java.util.Scanner;

public class MaxOccuringChar {
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter a string");
    String str = sc.nextLine();
    int count[] = new int[256];
    int max = -1;
    char result = ' ';
    for (int i = 0; i < str.length(); i++) {
      count[str.charAt(i)]++;
    }
    for (int i = 0; i < str.length(); i++) {
      if (max < count[str.charAt(i)]) {
        max = count[str.charAt(i)];
        result = str.charAt(i);
      }
    }
    System.out.println("Maximum occurring character is " + result);
  }
}