public class SplitMethod {
  public static void splitChar(String str) {
    String word[] = str.split(" ");
    for (int i = 0; i < word.length; i++) {
      System.out.println(word[i]);
    }
  }

  public static void main(String args[]) {
    splitChar("Welcome to Bitlabs");
  }
}