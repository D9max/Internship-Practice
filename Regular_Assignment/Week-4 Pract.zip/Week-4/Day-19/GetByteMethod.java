// public class GetByteMethod {
//     public static void main(String[] args) {
//         String myString = "Hello, world!";
//         byte myBytes[] = myString.getBytes();
//         System.out.println("Byte representation of the string:");
//         for (byte b : myBytes) {
//             System.out.print(b + " ");
//         }
//         System.out.println();
//     }
// }

class GetBytes{
  static void getBytess(String s){
    byte b[]=s.getBytes();
    for(int i=0;i<b.length;i++){
      System.out.println(b[i]);
    }
  }
  public static void main(String args[]){
    getBytess("messi");
  }
}