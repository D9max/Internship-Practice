import java.util.Scanner;

public class TextGenerator {
  public static int countCharacters(String text) {	
		int count = 0;	
		for(int i = 0; i < text.length(); i++) {
  	if(text.charAt(i) != ' ') {	
				count++;	
			}
    }
		return count;	
	}
	public static int countWords(String text) {
		int count = 0;
		for(int i = 0; i < text.length(); i++) {
			if(text.charAt(i) == ' ') {
				count++;
			}
		}	
		return count + 1;
  }
	public static int countLines(String text) {
		int count = 0;
		for(int i = 0; i < text.length(); i++) {
			if(text.charAt(i) == '\n') {
				count++;	
			}	
		}
		return count + 1;	
	}
	public static String mostCommonWords(String text) {
		String[] words = text.split(" ");
		int[] count = new int[words.length];
		for(int i = 0; i < words.length; i++) {
			for(int j = 0; j < words.length; j++) {
				if(words[i].equals(words[j])) {
					count[i]++;
				}
		}
 }
		int max = count[0];
		int index = 0;
		for(int i = 0; i < count.length; i++) {
			if(count[i] > max) {
				max = count[i];
				index = i;
			}
		}
		return words[index];
  }
	public static void main(String[] args) {	
		Scanner input = new Scanner(System.in);
		System.out.println("Enter a text: ");
		String text = input.nextLine();
		System.out.println("Number of characters: " + countCharacters(text));
		System.out.println("Number of words: " + countWords(text));
		System.out.println("Number of lines: " + countLines(text));
		System.out.println("Most common words: " + mostCommonWords(text));
  }
}