public class ToStringMeth {
  public static String toString(String s) {
    return "Name: " + s.name + ", Age: " + s.age;
  }

  public static void main(String[] args) {
    String s = new String("John Doe", 30);
    System.out.println(s.toString(s));
  }
}