import java.util.Scanner;

public class DArrayDemo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        int max = 0;

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                int m = scanner.nextInt();
                if (m != 20 && m > max) {
                    max = m;
                }
            }
        }

        System.out.println(max);
    }
}
