import java.util.Scanner;

public class EqualMatrices {
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    System.out.println("enter number of row and col :");
    int r = sc.nextInt();
    int c = sc.nextInt();
    int mat1[][] = new int[r][c];
    int mat2[][] = new int[r][c];
    System.out.println("enter first maatrix");
    for (int i = 0; i < r; i++) {
      for (int j = 0; j < c; j++) {
        mat1[i][j] = sc.nextInt();
      }
    }
    System.out.println("enter second matrix");
    {
      for (int i = 0; i < r; i++) {
        for (int j = 0; j < c; j++) {
          mat2[i][j] = sc.nextInt();
        }
      }
      boolean flag = true;
      for (int i = 0; i < r; i++) {
        for (int j = 0; j < c; j++) {
          if (mat1[i][j] != mat2[i][j]) {
            break;
          }
        }
      }
      if (flag) {
        System.out.println("equal");
      } else {
        System.out.println("not Equal");
      }
    }
  }
}