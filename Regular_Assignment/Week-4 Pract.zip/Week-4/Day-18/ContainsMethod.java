import java.util.*;

class ContainsMethod {

  static void checkSubString(String str1, String subString) {
    if (str1.contains(subString)) {
      System.out.println("valid");
    } else {
      System.out.println("invalid");
    }
  }

  public static void main(String args[]) {
    Scanner sc = new Scanner(System.in);
    String str1, subString;
    System.out.println("enter first string");
    str1 = sc.nextLine();
    System.out.println("enter string string");
    subString = sc.nextLine();

    checkSubString(str1, subString);

  }
}