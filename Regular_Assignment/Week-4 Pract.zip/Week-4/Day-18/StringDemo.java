// class StringDemo {
//   static void waysTocreate() {
//     char a[] = { 'a', 'e', 'i', 'o', 'u' };
//     String str = new String(a);

//     // 2nd way
//     String str1 = new String("mubarak");
//     // 3d way
//     String str2 = "Mubarak";
//     System.out.println(str);
//     System.out.println(str1);
//     System.out.println(str2);
//   }

//   public static void main(String args[]) {
//     waysTocreate();
//   }
// }
import java.util.*;

class StringDemo {// read Character

  static void getCharacter(String str) {
    System.out.println(str.charAt(12));
  }

  public static void main(String args[]) {
    Scanner sc = new Scanner(System.in);
    System.out.println("enter string");
    String str1 = sc.nextLine();
    System.out.println(str1);
    getCharacter(str1);

  }
}