import java.util.*;

class TwoStringAreEqual {
  static void compareTwoString(String str1, String str2) {
    if (str1.equals(str2)) {
      System.out.println("String are equal");
    } else {
      System.out.println("not equal");
    }
  }

  public static void main(String args[]) {
    Scanner sc = new Scanner(System.in);
    String str1, str2;
    System.out.println("Enter first String");
    str1 = sc.next();
    System.out.println("Enetr Second String");
    str2 = sc.next();
    compareTwoString(str1, str2);
  }
}