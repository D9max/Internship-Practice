public class SubstringAnalyzer {
  public static void main(String[] args) {
    String substring = "Mubarak@123";
    char charCount = substring.length();
    int alphabetCount = 0;
    int digitCount = 0;
    int specialCharCount = 0;

    for (int i = 0; i < charCount; i++) {
      char c = substring.charAt(i);
      if (Character.isLetter(c)) {
        alphabetCount++;
      } else if (Character.isDigit(c)) {
        digitCount++;
      } else {
        specialCharCount++;
      }
    }

    System.out.println(substring);
    System.out.println("number of characters: " + charCount);
    System.out.println("number of alphabets: " + alphabetCount);
    System.out.println("number of digits: " + digitCount);
    System.out.println("number of special characters: " + specialCharCount);
  }
}