// import java.util.*;

// public class ReverseAString {
//   static void reverseString(String str) {
//      char a[]=str.toCharArray();
//     String rev="";
//     for(int i=a.length-1;i>=0;i--){
//       rev=rev+a[i];
//       System.out.println(rev);
//     }
//   }

//   public static void main(String args[]) {
//     reverseString("Mubarak");
//   }
// }
public class ReverseAString {
    public static void main(String[] args)
    {
        String str = "Mubarak";
        StringBuffer sbr = new StringBuffer(str);
        sbr.reverse();
        System.out.println(sbr);
    }
}