public class StringCharAt {
  static void charAt() {
    String s = "Mubarak";
    char ch = s.charAt(4);
    System.out.println(ch);
  }

  public static void main(String args[]) {
    charAt();
  }
}