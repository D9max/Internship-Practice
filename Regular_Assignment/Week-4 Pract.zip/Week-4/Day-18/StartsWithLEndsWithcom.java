import java.util.Scanner;

public class StartsWithLEndsWithcom {
  static void validateString(String str) {
    if (str.startsWith("l") || str.endsWith(".com")) {
      System.out.println("valid");
    } else {
      System.out.println("invalid");
    }
  }

  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    System.out.println("enter input");
    String str = sc.next();
    validateString(str);
  }
}