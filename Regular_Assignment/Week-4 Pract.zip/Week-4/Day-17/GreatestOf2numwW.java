import java.util.Scanner;

class GreatestOf2numwW {
  static void printNumbers(int n) {
    for (int i = 1; i <= n; i++) {
      System.out.println(i);
    }
  }
  public static void main(String args[]) {
    printNumbers(20);

  }
}