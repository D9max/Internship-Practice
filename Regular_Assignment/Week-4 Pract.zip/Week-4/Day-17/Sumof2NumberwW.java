import java.util.Scanner;

class Sumof2NumberwW {
  static int sum(int a, int b) {

    return a + b;
  }

  public static void main(String args[]) {
    int sum = Sumof2NumberwW.sum(2, 3);
    System.out.println(sum);
  }
}