import java.util.*;

class SumOfTwoNumWW {
  static void sum() {
    int a, b;
    a = 10;
    b = 20;
    System.out.println(a + b);
  }

  public static void main(String args[]) {
    SumOfTwoNumWW.sum();
  }
}