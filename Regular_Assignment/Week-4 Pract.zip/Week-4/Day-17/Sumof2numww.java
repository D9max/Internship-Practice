import java.util.Scanner;
class Sumof2numww{
  static void sum(int a,int b){
    
   System.out.println(a+b);
  }
  public static void main(String args[]){
      Sumof2numww.sum(2,3);
  
  }
}