import java.util.Scanner;

public class UpperTriangleMatrix {
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    System.out.println("enter no row and col");
    int rows = scanner.nextInt();
    int columns = scanner.nextInt();
    int[][] matrix = new int[rows][columns];
    System.out.println("Enter elements of matrix");
    for (int i = 0; i < rows; i++) {
      for (int j = 0; j < columns; j++) {
        matrix[i][j] = scanner.nextInt();
      }
    }
    System.out.println("The upper triangular matrix is");
    for (int i = 0; i < rows; i++) {
      for (int j = 0; j < columns; j++) {
        if (i <= j) {
          System.out.print(matrix[i][j] + " ");
        } else {
          System.out.print("0 ");
        }
      }
      System.out.println();
    }
  }
}