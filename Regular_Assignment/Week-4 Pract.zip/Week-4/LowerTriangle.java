import java.util.Scanner;

class LowerTriangle {
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter size of matrix");
    int n = sc.nextInt();
    int mat[][] = new int[n][n];
    System.out.println("enter element of matrix");
    for (int i = 0; i < n; i++) {
      for (int j = 0; j < n; j++) {
        mat[i][j] = sc.nextInt();
      }
    }
    System.out.println("trianguler matrix");
    for (int i = 0; i < n; i++) {
      for (int j = 0; j <= i; j++) {
        System.out.print(mat[i][j] + " ");
      }
      System.out.println();
    }
  }
}