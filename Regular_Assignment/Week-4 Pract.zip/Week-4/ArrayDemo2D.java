import java.util.*;

public class ArrayDemo2D {

  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    System.out.println("enter row");
    int n = sc.nextInt();
    System.out.println("Enter Element");
    int[][] arr = new int[n][n];
    for (int i = 0; i < n; i++) {
      for (int j = 0; j < n; j++) {
        arr[i][j] = sc.nextInt();
      }
      System.out.println();
    }
    int count = 0;
    for (int i = 0; i < n; i++) {
      for (int j = 0; j < n; j++) {
        if (arr[i][j] != 20) {
          count++;
        }
      }
    }
    System.out.print(count);
  }
}