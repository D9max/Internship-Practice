import java.util.Scanner;

public class SubtractionMatrix {
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);

    System.out.print("Enter number of rows: ");
    int rows = scanner.nextInt();
    System.out.print("Enter  number of columns: ");
    int columns = scanner.nextInt();

    int[][] firstMatrix = new int[rows][columns];
    int[][] secondMatrix = new int[rows][columns];

    System.out.println("Enter first matrix:");

    for (int i = 0; i < rows; i++) {
      for (int j = 0; j < columns; j++) {
        firstMatrix[i][j] = scanner.nextInt();
      }
    }

    System.out.println("Enter the second matrix:");

    for (int i = 0; i < rows; i++) {
      for (int j = 0; j < columns; j++) {
        secondMatrix[i][j] = scanner.nextInt();
      }
    }

    int[][] differenceMatrix = new int[rows][columns];

    for (int i = 0; i < rows; i++) {
      for (int j = 0; j < columns; j++) {
        differenceMatrix[i][j] = firstMatrix[i][j] - secondMatrix[i][j];
      }
    }

    System.out.println(" difference of the two matrices is:");

    for (int i = 0; i < rows; i++) {
      for (int j = 0; j < columns; j++) {
        System.out.print(differenceMatrix[i][j] + " ");
      }
      System.out.println();
    }

    scanner.close();
  }
}
