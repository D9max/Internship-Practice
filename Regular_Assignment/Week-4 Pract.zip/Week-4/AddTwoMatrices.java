import java.util.Scanner;

public class AddTwoMatrices {
  public static void main(String args[]){
    Scanner sc = new Scanner(System.in);
     System.out.print("Enter the number of rows in the matrix ");
        int rows = sc.nextInt();
    System.out.println("Enter the number of columns");
    int col = sc.nextInt();
    int[][] mat1=new int[rows][col];
    int[][] mat2=new int[rows][col];
    int[][] sum=new int[rows][col];
    System.out.println("enter element");
    for(int i=0;i<=rows;i++){
      for(int j=0;j<=col;j++){
      mat1[i][j]=sc.nextInt();
    }
  }
    System.out.println("enter element");
    for(int i=0;i<=rows;i++){
      for(int j=0;j<=col;j++){
      mat2[i][j]=sc.nextInt();
      }
    }
     System.out.println("enter element");
    for(int i=0;i<=rows;i++){
      for(int j=0;j<=col;j++){
      sum[i][j]=mat1[i][j]+mat2[i][j];
      }
    }
    System.out.println("sum of mat");
    for(int i=0;i<=rows;i++){
      for(int j=0;j<=col;j++){
        System.out.println(sum[i][j]+" ");
      }
      System.out.println();
    }
  }
}
