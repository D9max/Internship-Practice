import java.util.*;
public class MultipleOfMatrix{
  public static void main(String[] args){
    Scanner sc = new Scanner(System.in);
    System.out.println("aenter num of row & col");
    int r1=sc.nextInt();
    int c1=sc.nextInt();
    int m1[][]=new int[r1][c1];
    System.out.println("enter first matrix");
    for(int i=0;i<r1;i++){
      for(j=-0;j<c1;j++){
        m1[i][j]=sc.nextInt();
      }
    }
    System.out.println("enter no of Rows & colms");
    int r2=sc.nextInt();
    int c2=sc.nextInt();
    int m2[][]=new int[r2][c2];
    System.out.println("enter second matrix");
    for(int i=0;i<r2;i++){
      for(int j=-0;j<c2;j++){
        m2[i][j]=sc.nextInt();
}
}
if(c1!=r2){
  System.out.println("not multiplied");
}
    else{
      int product[][]=new int[r1][c2];
       for(int j=-0;j<c2;j++){
          for(int k=-0;k<c2;k++){
            product[k][j] += m1[k][j]*m2[k][j];
          }
       }
  System.out.println("product of matrices is :");
  for(int[] row:product){
    for(int c:row){
      System.out.println(c+" ");
    }
    System.out.println();
  }
}
}
}
