// import java.util.*;
// public class NumbersDivisibleBy5 {
//     public static void main(String[] args) {
//         int[][] array = new int[][]{{5, 2, 10, 4, 6}, {2, 7, 15, 9, 25}};
//         for (int i = 0; i < array.length; i++) {
//             for (int j = 0; j < array[i].length; j++) {
//                 if (array[i][j] % 5 == 0) {
//                     System.out.println(array[i][j]);
//                 }
//             }
//         }
//     }
// }

import java.util.Scanner;
  class TwoDivisible{
    public static void main(String args[]){
      Scanner sc=new Scanner(System.in);
      int a[][]={{2,5,15},{20,60,70},{4,5,6}};
      for(int i=0;i<3;i++){
        int count=0;
        for(int j=0;j<3;j++){
          if(a[i][j]%5==0){
           count++;
          }}
        System.out.println(count);
       
      }
    }
  }