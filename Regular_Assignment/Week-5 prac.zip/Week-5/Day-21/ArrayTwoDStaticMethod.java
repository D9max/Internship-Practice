// import java.util.*;
// public class ArrayTwoDStaticMethod{
//   public static void main(String args[]){
//     String arr[][]=new String[2][2];
//     int i,j;
//     System.out.println("enter elements");
//     for(i=0;i<2;i++){
//       for(j=0;j<2;j++){
//         arr[i][j]=sc.nextInt();
//       }
//       System.out.println("enter elements");
//       for(i=0;i<arr[i].length;i++){
//         for(j=0;j<arr[i].length;j++){
//           arr[i][j]=sc.nextInt();
//         }
//       }
//       System.out.println();
//     }
//   }
// }
import java.util.*;
public class ArrayTwoDStaticMethod
{
    public static void main(String[] args) {
    char a[][]=new char[2][3];
    Scanner sc=new Scanner(System.in);
    for(int i=0;i<2;i++){
        for(int j=0;j<3;j++){
            a[i][j]=sc.next().charAt(0);
        }
    }
    }
}