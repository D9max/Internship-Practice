import java.util.Scanner;

public class TwoDStaticArray {
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    System.out.print("Enter the number of rows: ");
    int numRows = sc.nextInt();
    System.out.print("Enter the number of columns: ");
    int numCols = scanner.nextInt();

    char[][] charArray = new char[2][2];
    for (int i = 0; i < 2; i++) {
      for (int j = 0; j < 2; j++) {
        System.out.print("Enter a character for row and column");
        charArray[i][j] = sc.next().charAt(0);
      }
    }
    for (int i = 0; i < charArray.length; i++) {
      for (int j = 0; j < charArray[i].length; j++) {
        System.out.print(charArray[i][j] + " ");
      }
      System.out.println();
    }
  }
}