import java.util.StringTokenizer;

public class reverseString {
  public static void main(String[] args) {
    String str = "Welcome to bitlabs";
    String reversed = reverseEachToken(str);
    System.out.println(reversed);
  }
  public static String reverseEachToken(String str) {
    StringTokenizer tokenizer = new StringTokenizer(str);
    StringBuilder sb = new StringBuilder();
    while (tokenizer.hasMoreTokens()) {
      String token = tokenizer.nextToken();
      sb.append(reverse(token)).append(" ");
    }
    return sb.toString();
  }
  public static String reverse(String s) {
    StringBuilder sb = new StringBuilder(s);
    return sb.reverse().toString();
  }

}
