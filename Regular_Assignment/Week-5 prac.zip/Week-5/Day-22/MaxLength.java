import java.util.StringTokenizer;

public class MaxLength {
  public static void main(String[] args) {
    String input = "welcome to bitlabs";
    StringTokenizer tokenizer = new StringTokenizer(input);
    int maxLength = 0;
    while (tokenizer.hasMoreTokens()) {
      String token = tokenizer.nextToken();
      int length = token.length();
      if (length > maxLength) {
        maxLength = length;
      }
    }
    System.out.println("The maximum token length in the given string is: " + maxLength);
  }
}
// import java.util.StringTokenizer;
// class MaxLength{
//   public static void main(String args[]){
//     StringTokenizer s=new StringTokenizer("Hello Bitlabs");
//     int maxLength=0;
//     while(s.hasMoreTokens()){
//       String token=s.nextToken();
//       int length=token.length();
//       if(length>maxLength){
//         maxLength=length;
//       }
//     }
//     System.out.println("The maximum token length is:" +maxLength);
//   }
//}