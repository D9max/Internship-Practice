import java.util.StringTokenizer;

public class LengthofEachToken {
  public static void main(String[] args) {
    String sc = "Welcomr to bitlabs";
    StringTokenizer tokenizer = new StringTokenizer(sc);
    System.out.println("Token length:");
    while (tokenizer.hasMoreTokens()) {
      String s = tokenizer.nextToken();
      System.out.println(s.length());
    }
  }
}