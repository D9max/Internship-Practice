import java.util.*;
import java.util.StringTokenizer;

public class CountNoofTokens {
  public static void main(String args[]) {
    StringTokenizer s = new StringTokenizer("welcome to bitlabs");
    System.out.println("total number of tokens :" + s.countTokens());
  }
}