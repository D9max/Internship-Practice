import java.util.*;
public class StringSplit {
  public static void main(String args[]) {
    String s1 = "welcome to bitlabs";
    String[] words = s1.split("\\s");
    for (String w : words) {
      System.out.println(w);
    }
  }
}