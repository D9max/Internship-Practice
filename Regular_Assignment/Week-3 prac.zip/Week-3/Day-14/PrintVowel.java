public class PrintVowel {
  public static void main(String[] args) {
    char[] ch = { 'a', 'e', 'i', 'o', 'u', 'A', 'E', 'I', 'O', 'U' };
    for (int i = 0; i < ch.length; i++) {
      System.out.println(ch[i]);
    }
  }
}
