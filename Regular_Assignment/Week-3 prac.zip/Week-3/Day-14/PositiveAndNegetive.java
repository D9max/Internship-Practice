import java.util.Scanner;

class PositiveAndNegetive {
  public static void main(String args[]) {
    int positive = 0, negetive = 0;
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter the number of elements");
    int n = sc.nextInt();
    int arr[] = new int[n];
    System.out.println("Enter the elements");
    for (int i = 0; i < n; i++) {
      arr[i] = sc.nextInt();
    }
    for (int i = 0; i < n; i++) {
      if (arr[i] > 0) {
        positive++;
      } else {
        negetive++;
      }
    }
    System.out.println("positive :" + positive);
    System.out.println("negetive :" + negetive);
  }
}
