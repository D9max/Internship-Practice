import java.util.*;

class ArrayPrac {
  public static void main(String[] args) {

    double arr[] = new double[5];
    Scanner sc = new Scanner(System.in);
    System.out.print("enter values:");
    for (int i = 0; i < 5; i++) {
      arr[i] = sc.nextDouble();
    }
    //even no
    System.out.println("Array elements are :");
    for (int i = 0; i <= 5; i++) {
      if (arr[i] == 0)
        System.out.println("a[" + i + "]=" + a[i]);
    }
  }
}