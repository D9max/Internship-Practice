import java.util.*;

class Multiplication {
  public static void main(String args[]) {
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter Array Size");
    int n = sc.nextInt();
    int arr[] = new int[n];
    System.out.println("enter the array elements");
    for (int i = 0; i < arr.length; i++) {
      arr[i] = sc.nextInt();
    }
    System.out.println("enter the choice");
    System.out.println("1. insert an element in first index");
    System.out.println("2. Insert an element in last index");
    System.out.println("3. Insert an element in specified index");
    System.out.println("4. Remove element from first index");
    System.out.println("5. Remove element from last index");
    System.out.println("6. Remove element from specified index");
    System.out.println("7. Remove user eneted element");
    System.out.println("8.Display all in ASC/DESC order");
    int choice = sc.nextInt();
    switch (choice) {
      case 1:
        System.out.println("enter the element to be insert in the first index");
        int elements = sc.nextInt();
        for (int i = arr.length - 1; i > 0; i--) {
          arr[i] = arr[i - 1];
        }
        arr[0] = elements;
    }
    System.out.println("the array elements are:");
    for (int i = 0; i < arr.length; i++) {
      System.out.println(arr[i] + "");
    }
    break;
    case 2: 
    System.out.println("Enter the element to be inserted in last index");
    int ele1 = sc.nextInt();

    arr[arr.length - 1] = ele1;

    System.out.println("Array after inserting element in last index");
    for (int i = 0; i < arr.length; i++) {
      System.out.print(arr[i] + " ");
    }
    break;
    
    case 3:
			System.out.println("Enter the element to be inserted in specified index");
			int ele2 = sc.nextInt();
			
			System.out.println("Enter the index");
			int index = sc.nextInt();
			
			for(int i=arr.length-1; i>index; i--) {
				arr[i] = arr[i-1];
			}
			arr[index] = ele2;
			
			System.out.println("Array after inserting element in specified index");
			for(int i=0; i<arr.length; i++) {
				System.out.print(arr[i]+" ");
			}
			break;
    case 4:
			for(int i=0; i<arr.length-1; i++) {
				arr[i] = arr[i+1];
			}
			arr[arr.length-1] = 0;
			
			System.out.println("Array after removing element from first index");
			for(int i=0; i<arr.length; i++) {
				System.out.print(arr[i]+" ");
			}
			break;
			
		case 5:
			arr[arr.length-1] = 0;
			
			System.out.println("Array after removing element from last index");
			for(int i=0; i<arr.length; i++) {
				System.out.print(arr[i]+" ");
			}
			break;
    	
		case 6:
			System.out.println("Enter the index");
			int index1 = sc.nextInt();
			
			for(int i=index1; i<arr.length-1; i++) {
				arr[i] = arr[i+1];
			}
			arr[arr.length-1] = 0;
			
			System.out.println("Array after removing element from specified index");
			for(int i=0; i<arr.length; i++) {
				System.out.print(arr[i]+" ");
			}
			break;
    case 7:
			System.out.println("Enter the element to be removed");
			int ele3 = sc.nextInt();
			
			int index2 = 0;
			for(int i=0; i<arr.length; i++) {
				if(arr[i] == ele3) {
					index2 = i;
					break;
				}
			}
			
			for(int i=index2; i<arr.length-1; i++) {
				arr[i] = arr[i+1];
			}
			arr[arr.length-1] = 0;
			
			System.out.println("Array after removing user entered element");
			for(int i=0; i<arr.length; i++) {
				System.out.print(arr[i]+" ");
			}
			break;
    case 8:
			System.out.println("Enter the choice");
			System.out.println("1. ASC");
			System.out.println("2. DESC");
			
			int choice1 = sc.nextInt();
  




  }
}