import java.util.Scanner;

public class InsertAtSpecificPosition {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the size of array");
        int size = scanner.nextInt();
        int[] array = new int[size];
        System.out.println("Enter the elements of array");
        for (int i = 0; i < size; i++) {
            array[i] = scanner.nextInt();
        }
        System.out.println("Enter the position where you want to insert");
        int position = scanner.nextInt();
        System.out.println("Enter the element you want to insert");
        int element = scanner.nextInt();
        for (int i = size - 1; i >= position - 1; i--) {
            array[i + 1] = array[i];
        }
        array[position - 1] = element;
        System.out.println("After inserting element at specific position");
        for (int i = 0; i < size + 1; i++) {
            System.out.println(array[i]);
        }
    }
}
