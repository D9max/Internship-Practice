import java.util.Scanner;

class InsertFirstPosition{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of array");
		int size = sc.nextInt();
		int arr[] = new int[size];
		System.out.println("Enter the elements of array");
		for(int i=0;i<size;i++)
		{
			arr[i] = sc.nextInt();
		}
		System.out.println("Enter the element to be inserted at first position");
		int element = sc.nextInt();
		for(int i=size-1;i>=0;i--)
		{
			arr[i+1] = arr[i];
		}
		arr[0] = element;
		System.out.println("Array after inserting element at first position");
		for(int i=0;i<size+1;i++)
		{
			System.out.println(arr[i]);
		}
	}
}
