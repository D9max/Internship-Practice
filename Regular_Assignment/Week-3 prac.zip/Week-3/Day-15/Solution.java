import java.io.*;
import java.util.*;

// public class Solution {
//public class Solution
//{
   //  public static void main(String[] args) {

//    int B,H;
//    boolean flag = true;
//         Scanner sc = new Scanner(System.in);
//         B = sc.nextInt();
//         H = sc.nextInt();
//       if(H>0){
//         System.out.println(H);
//       }else{
//         if(B<=0 || H<=0)
//             System.out.println("java.lang.Exception: Breadth and height must be positive");
//             flag = false;
//         }
//     }
// }

public class Solution {
 public static void main(String[] args) {
 Scanner scan = new Scanner(System.in);
 int B = scan.nextInt();
 int H = scan.nextInt();
 boolean flag = true;

    try{
        if(B <= 0 || H <= 0){
            flag = false;
            throw new Exception("Breadth and height must be positive");
        }
    }catch(Exception e){
        System.out.println(e);
    }
		if(flag){
			int area=B*H;
			System.out.print(area);
		}
		
	}
}
     