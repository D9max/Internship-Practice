import java.util.Scanner;

class InsertLast{
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		int arr[] = new int[5];
		int i,j,temp;
		System.out.println("Enter the elements of array");
		for(i=0;i<5;i++){
			arr[i] = sc.nextInt();
		}
		System.out.println("Enter the element to be inserted");
		temp = sc.nextInt();
		arr[4] = temp;
		System.out.println("The array after insertion is");
		for(i=0;i<5;i++){
			System.out.println(arr[i]);
		}
	}
}
