import java.util.Scanner;

class ArrayMidPosi{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of array");
		int n = sc.nextInt();
		int arr[] = new int[n];
		System.out.println("Enter the elements of array");
		for(int i=0;i<n;i++)
		{
			arr[i] = sc.nextInt();
		}
		System.out.println("Enter the value to be inserted");
		int val = sc.nextInt();
		int pos = n/2;
		for(int i=n-1;i>=pos;i--)
		{
			arr[i+1] = arr[i];
		}
		arr[pos] = val;
		System.out.println("The new array is");
		for(int i=0;i<n+1;i++)
		{
			System.out.println(arr[i]);
		}
	}
}
