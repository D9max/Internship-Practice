// import java.util.Random; 
// import java.util.Scanner;
// class Guessinggame{
//   public static void main(String args[]){
//     Scanner sc=new Scanner(System.in);
//     Random random = new Random(); 
//     int randomnumber=random.nextInt(100);
//     //System.out.println(randomnumber);
//     int Guess=0;
//     do{
//       System.out.println("Guess Number:");
//       Guess=sc.nextInt();
//       if(randomnumber==Guess)
//         System.out.println(" Correct Guess!!Congrats");
//       else
//         System.out.println(" Incorrect Guess!!Try Again");
//     }while(randomnumber!=Guess);
//   }
// }

import java.util.Scanner;

public class NumberGuessing {
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    int randomNumber = (int) (Math.random() * 100);
    int guessNumber;
    System.out.println("Guess a number between 1 and 100");
    do {
      System.out.println("Guess Number:");
      guessNumber = sc.nextInt();
      if (randomNumber == guessNumber)
        System.out.println(" Correct Guess.....!!");
      else
        System.out.println(" Incorrect Guess pls Try Again");
    } while (randomNumber != guessNumber);
  }
}