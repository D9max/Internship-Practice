// import java.util.Arrays;

// public class UniqueElements {
//     public static void main(String[] args) {
//         int[] arr = { 1, 2, 3, 4, 5, 1, 2, 6, 7, 8, 9, 3 };
//         int n = arr.length;
//         Arrays.sort(arr);
//         for (int i = 0; i < n; i++) {
//             if (i == 0 || arr[i] != arr[i - 1]) {
//                 System.out.print(arr[i] + " ");
//             }
//         }
//     }
// }
import java.util.Scanner;

public class UniqueElements {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of the array");
		int size = sc.nextInt();
		int[] arr = new int[size];
		System.out.println("Enter the elements of the array");
		for (int i = 0; i < size; i++) {
			arr[i] = sc.nextInt();
		}
		for (int i = 0; i < size; i++) {
			int count = 0;
			for (int j = 0; j < size; j++) {
				if (arr[i] == arr[j]) {
					count++;
				}
			}
			if (count == 1) {
				System.out.println(arr[i]);
			}
		}
	}
}
