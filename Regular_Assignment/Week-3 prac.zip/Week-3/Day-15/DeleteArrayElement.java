import java.util.Scanner;

public class DeleteArrayElement {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the size of an array");
        int size = scanner.nextInt();
        int[] array = new int[size];
        System.out.println("Enter the elements of an array");
        for (int i = 0; i < size; i++) {
            array[i] = scanner.nextInt();
        }
        System.out.println("Enter which element to delete");
        int index = scanner.nextInt();
        for (int i = index; i < size - 1; i++) {
            array[i] = array[i + 1];
        }
        System.out.println("After deleting remaining elements array");
        for (int i = 0; i < size - 1; i++) {
            System.out.println(array[i]);
        }
    }
}