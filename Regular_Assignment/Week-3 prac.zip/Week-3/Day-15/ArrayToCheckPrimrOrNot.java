import java.util.Scanner;
class ArrayToCheckPrimrOrNot{
  public static void main(String args[]){
    int a[]=new int[5];
    Scanner sc=new Scanner(System.in);
    System.out.println("enter values");
    for(int i=0;i<5;i++){
     a[i]=sc.nextInt();
   }
    System.out.println("prime numbers");
    for(int i=0;i<5;i++){
      int count=0;
      for(int j=2;j<=a[i]/2;j++){
        if(a[i]%j==0){
          count++;
        }
      }
      if(count==0){
        System.out.println(a[i]);
      }    
    }
