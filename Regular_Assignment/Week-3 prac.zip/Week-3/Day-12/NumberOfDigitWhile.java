import java.util.Scanner;

public class NumberOfDigitWhile {
  public static void main(final String[] args) {
    int n,count=0;
    final Scanner sc = new Scanner(System.in);
    System.out.println("Enter a number: ");
    n = sc.nextInt();
    
    while (n != 0) {
      n = n / 10;
      count++;
    }
    System.out.println("Number of digits is : " + count);
  }
}