import java.util.*;

class WhileLNaturalN {
  public static void main(String args[]) {
    int n, i = 1, sum = 0;
    Scanner sc = new Scanner(System.in);
    System.out.println("enter n value");
    n = sc.nextInt();
    while (i <= n) {
      sum = sum + i;
      System.out.println(sum);
      i++;
    }
  }
}