import java.util.*;

public class EvenNo1ton {
  public static void main(String args[]) {
    int n, i;
    Scanner sc = new Scanner(System.in);
    System.out.println("enter n number");
    n = sc.nextInt();
    System.out.println("even number");

    for (i = 0; i <= n; i++) {
      if (i % 2 == 0) {
        System.out.println(i);
      }
    }
  }
}