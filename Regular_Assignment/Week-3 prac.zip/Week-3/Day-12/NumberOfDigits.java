
import java.util.Scanner;

public class NumberOfDigits {
    public static void main(String[] args) {
      int n,count=0;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a number: ");
        n = sc.nextInt();
        count = 0;
        for (;n != 0; n /= 10,count++) ;
        System.out.println("Number of digits is : " +count);
    }
}