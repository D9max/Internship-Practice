import java.util.*;

class WhileLNaturalN {
  public static void main(String args[]) {
    char c = 'A'; 
    while (c <= 'Z') {
      System.out.println(c);
      c++;
    }
  }
}