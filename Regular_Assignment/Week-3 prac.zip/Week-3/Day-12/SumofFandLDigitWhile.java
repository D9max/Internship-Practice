
import java.util.Scanner;

public class SumofFandLDigitWhile {

  public static void main(String[] args) {
    int n, fd = 0, ld = 0, sum = 0;
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter a number");
    n = sc.nextInt();
    int i = n;
    while (n > 0) {
      ld = i % 10;
      fd = n % 10;
      n = n / 10;
      sum = ld + fd;
    }
    System.out.println("First number is: " + fd);
    System.out.println("Last number is: " + ld);
    System.out.println("First and Last digit of the number is: " + sum);

  }

}
