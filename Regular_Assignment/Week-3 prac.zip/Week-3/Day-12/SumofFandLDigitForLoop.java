import java.util.*;

public class SumofFandLDigitForLoop {

  public static void main(String[] args) {
    int fd = 0, ld = 0, n, sum = 0;
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter a number");
    n = sc.nextInt();
    for (int i = n; i > 0; i = i / 10) {
      fd = i % 10;
      ld = n % 10;
      sum = fd + ld;
    }
    System.out.println("First number is: " + fd);
    System.out.println("Last number is: " + ld);
    System.out.println("The First and last digit of the number is: " + sum);

  }

}
