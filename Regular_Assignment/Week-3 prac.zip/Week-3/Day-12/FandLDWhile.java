
import java.util.Scanner;

public class FandLDWhile {

  public static void main(String[] args) {
    int n, fd = 0, ld = 0;
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter a number");
    n = sc.nextInt();
    int i = n;
    while (n > 0) {
      ld = i % 10;
      fd = n % 10;
      n = n / 10;
    }
    System.out.println("First digit of the number is: " + fd);
    System.out.println("Last digit of the number is: " + ld);
  }

}
