import java.util.*;

public class SumofNnumberDivisibleBy5 {
  public static void main(String args[]) {
    int n, i, sum = 0;
    Scanner sc = new Scanner(System.in);
    System.out.println("enter n value");
    n = sc.nextInt();
    while(i<=n){
      if(i%5==0){
        sum=sum+i;
        System.out.println(i);
        i++;
      }
    }
  }