import java.util.*;

public class SumofFandLDigitDoWhile {

  public static void main(String[] args) {
    int fd = 0, ld = 0, n, sum = 0;
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter a number");
    n = sc.nextInt();
    int i = n;
    do {
      ld = i % 10;
      fd = n % 10;
      n = n / 10;
      sum = ld + fd;
    } while (n > 0);
    System.out.println("First number is: " + fd);
    System.out.println("Last number is: " + ld);
    System.out.println("First and Last digit of the number is: " + sum);
  }
}


// import java.util.*;
// class LoopsDemo  { 
//   public static void main(String args[]){   
//     Scanner sc=new Scanner(System.in);
//     System.out.println("Enter n value");  
//     int n=sc.nextInt();   
//     int lastdigit=n%10;   
//     while(n>10){     
//       n=n/10;    
//     }   
//     int firstdigit=n;  
//     System.out.println("firstdigit "+firstdigit);  
//     System.out.println("lastdigit "+lastdigit);   
//   } 
// }