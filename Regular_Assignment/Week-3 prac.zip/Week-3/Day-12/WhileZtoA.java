class WhileZtoA {
  public static void main(String args[]) {
    char i = 'z';
    while (i >= 'a') {
      System.out.println((int)i);
      i--;
    }
  }
}