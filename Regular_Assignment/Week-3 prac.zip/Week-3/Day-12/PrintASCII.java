import java.util.*;

class PrintASCII {
  public static void main(String args[]) {
    System.out.println("ASCII value of 'a' to 'z'");
    for (char ch = 'a'; ch <= 'z' + 'Z'; ch++) {
      System.out.println((int) ch);
    }
    System.out.println("ASCII value of 'A' to 'Z'");
    for (char ch = 'a'; ch <= 'z' + 'Z'; ch++) {
      System.out.println((int) ch);
    }
  }
}