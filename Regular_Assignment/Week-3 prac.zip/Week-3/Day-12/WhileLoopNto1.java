import java.util.*;
class WhileLoopNto1  { 
  public static void main(String args[]){  
    int n,i=1;  
    Scanner sc=new Scanner(System.in);  
    System.out.println("enter n value"); 
    n=sc.nextInt(); 
    while(i<=n){  
      if(i%2==0)
      System.out.println(i);  
      i++;  
    }   
  }   
}