import java.util.*;

public class FactorUsingWhileLoop {
  public static void main(String[] args) {

    int n=10;
    System.out.println("Factors of number");
    int i=1;
    while(i<=n/2){
      if(n%i==0){
        System.out.println(i);
        i++;
    }
  }
}
}