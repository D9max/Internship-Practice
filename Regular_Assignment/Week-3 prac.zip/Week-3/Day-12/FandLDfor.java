import java.util.*;
public class FandLDfor {

	public static void main(String[] args) {
		int fd=0,ld=0,n;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number");
	  n = sc.nextInt();
		for(int i = n; i > 0; i = i/10) {
			fd = i%10;
			ld = n%10;
		}
		System.out.println("First digit of the number is: " + fd);
		System.out.println("Last digit of the number is: " + ld);
	}

}

