import java.util.Scanner;

public class SumOfDigit {
  public static void main(String[] args) {
    int num, sum;
    Scanner scanner = new Scanner(System.in);
    System.out.println("Enter a positive integer: ");
    num = scanner.nextInt();
    sum = 0;
    while (num > 0) {
    /* for reference to Find last digit of num and add to sum */
      sum += num % 10;
      num = num / 10;
    }
    System.out.println("sum of digit :" + sum);
  }
}