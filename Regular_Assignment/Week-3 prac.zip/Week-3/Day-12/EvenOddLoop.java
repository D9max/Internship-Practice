// import java.util.*;

// public class Demoo {
//   int a =10;
//  public void method (int a)
//   }
// }
// float f=75.0f;
// double d = 75.0;
// int i=75;
// if(f==d){
// if(f==i){
// System.out.println("fdandi");
// }
// else {
// System.out.println("fdare equal");
// }
// }
// else {
// System.out.println("fdare equal");
// }
// }
// }
import java.util.*;

public class EvenOddLoop {
 public static void main(String args[]){
   int n,i;
   Scanner sc = new Scanner(System.in);
   System.out.println("enter n number");
   n=sc.nextInt();
      System.out.println("even number");

   for(i=0;i<=n;i++){
     if(i%2==0){
       System.out.println(i);
   }
   }
       System.out.println("odd numbers");
      for(i=0;i<=n;i++){
     if(i%2!=0){
       System.out.println(i);
 }
 }
}
}
  