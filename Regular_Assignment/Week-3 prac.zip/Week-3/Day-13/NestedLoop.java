import java.util.Scanner;

class NestedLoop {
  public static void main(String[] args) {
    int i, j,k,num,end;
    Scanner sc = new Scanner(System.in);
    System.out.print("Enter the range ");
    num = sc.nextInt();
    end =sc.nextInt();
    for (i = num; i <= end; i++) {
      int count = 0;
      for (j = 1; j <= i; j++) {
        if(i%j==0)
          count++;

      }
      if(count==2)
      System.out.println(i);
  }
}
}