import java.util.Scanner;

class StrongNumber {
  public static void main(String[] args) {
    int i, j,k, num;
    Scanner sc = new Scanner(System.in);
    System.out.print("Enter a number: ");
    num = sc.nextInt();
    for (i = 1; i <= 5; i++) {
      for (j = 1; j <= 5; j++) {
        // for (k = 1; k <= 5; k++)
        System.out.print(i + " " + j );
      }
      System.out.println();
    }
  }
}
